/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   student.h
 * Author: 10531rg
 *
 * Created on September 17, 2018, 8:01 PM
 */

#ifndef BOOK_H
#define BOOK_H

typedef struct student STUDENT;

// Constructor
STUDENT* createStudent(int id, char* name, float gpa);

// Destructor
void deleteStudent(STUDENT* stu);

// Manipulator
void setGPA(STUDENT* stu, float gpa);

// Reporter
void printStudent(STUDENT *stu);



#endif /* BOOK_H */

