/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include<stdio.h> // scanf, printf
#include<stdlib.h> // malloc()
#include<string.h> // strcpy()

#include "book.h"

// Implementation of Student ADT
struct student 
{
    int id;
    char name[16];
    float gpa;

};

// Constructor
STUDENT* createStudent(int id, char* name, float gpa)
{
   STUDENT* stu = (STUDENT*) malloc(sizeof(STUDENT));
   stu->id = id;
   strcpy(stu->name, name);
   stu->gpa = gpa;
   return stu;
}

// Destructor
void deleteStudent(STUDENT* stu)
{
   free(stu); 
}

// Manipulator
void setGPA(STUDENT* stu, float gpa)
{
    stu->gpa = gpa;
    
}

// Reporter
void printStudent(STUDENT *stu)
{
    printf("ID = %d\n", stu->id);
    printf("Name = %s\n", stu->name);
    printf("GPA = %.1f\n", stu->gpa);
    
}